<?php 

 
$con = mysqli_connect("localhost", "root", "", "apcon") or die("Error " . mysqli_error($con));
// $con = mysqli_connect("localhost", "bhavyaresources_bhavyauser", "Bhavya@2021#", "bhavyaresources_bhavyadb") or die("Error " . mysqli_error($con));


?>