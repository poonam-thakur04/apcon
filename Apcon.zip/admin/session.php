<?php

if ($_SESSION['Bhavya_TGA'] == '') {
   echo' <script>window.location="index.php"</script>';
}
?>