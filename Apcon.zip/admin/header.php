 <header class="main-header">
	<div class="d-flex align-items-center logo-box justify-content-between">
		<a href="#" class="waves-effect waves-light nav-link rounded d-none d-md-inline-block mx-10 push-btn" data-toggle="push-menu" role="button">
			<i class="ti-menu"></i>
		</a>	
		<!-- Logo -->
		<a href="dashboard.php" class="logo">
		  <!-- logo-->
		  <div class="logo-lg">
			  <span class="light-logo">Bhavya Resources<!-- <img src="images/logo-dark-text.png" alt="logo"> --></span>
			  <span class="dark-logo">Bhavya Resources<!-- <img src="images/logo-light-text.png" alt="logo"> --></span>
		  </div>
		</a>	
	</div>  
    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top pl-10">
      
		
      <div class="navbar-custom-menu r-side">
        
      </div>
    </nav>
  </header>
  