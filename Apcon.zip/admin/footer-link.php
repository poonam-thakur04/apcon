
<script src="js/vendors.min.js"></script>
    <script src="assets/icons/feather-icons/feather.min.js"></script>	
    

	<script src="assets/vendor_components/apexcharts-bundle/dist/apexcharts.js"></script>
	<script src="assets/vendor_components/progressbar.js-master/dist/progressbar.js"></script>
	
	
	<script src="js/template.js"></script>
	<script src="js/pages/dashboard.js"></script>
	<script src="js/demo.js"></script>
	
	
