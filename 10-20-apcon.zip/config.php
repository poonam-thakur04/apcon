<?php 

 
$con = mysqli_connect("localhost", "root", "", "apcon") or die("Error " . mysqli_error($con));
// $con = mysqli_connect("localhost", "aadargld_apcon_user", "Sagar@11", "aadargld_apcon") or die("Error " . mysqli_error($con));


?>