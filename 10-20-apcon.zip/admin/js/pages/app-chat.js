//[app Javascript]


$(function () {
    "use strict";    
		
	 // chat app scrolling
  
	  $('.chat-box-one').slimScroll({
		height: '550'
	  });
	 $('.chat-box-one-side').slimScroll({
		height: '650'
	  });
	
  }); // End of use strict